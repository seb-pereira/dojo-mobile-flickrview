var profile = {
	resourceTags:{
		amd: function(filename, mid){
			return /\.js$/.test(filename);
		}
	}
};