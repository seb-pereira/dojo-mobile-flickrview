//>>built
define("dijit/form/nls/de/validate",{invalidMessage:"Der eingegebene Wert ist ung\u00fcltig. ",missingMessage:"Dieser Wert ist erforderlich.",rangeMessage:"Dieser Wert liegt au\u00dferhalb des g\u00fcltigen Bereichs. "});
//@ sourceMappingURL=validate.js.map