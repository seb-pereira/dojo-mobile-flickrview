//>>built
define("dijit/form/nls/ca/Textarea",{iframeEditTitle:"\u00e0rea d'edici\u00f3",iframeFocusTitle:"Marc de l'\u00e0rea d'edici\u00f3"});
//@ sourceMappingURL=Textarea.js.map