//>>built
define("dijit/form/nls/az/validate",{rangeMessage:"Bu d\u0259y\u0259r aral\u0131q xaricind\u0259.",invalidMessage:"Giril\u0259n d\u0259y\u0259r ke\u00e7\u0259rli deyil.",missingMessage:"Bu dey\u0259r laz\u0131ml\u0131."});
//@ sourceMappingURL=validate.js.map