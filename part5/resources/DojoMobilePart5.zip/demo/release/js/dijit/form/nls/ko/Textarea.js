//>>built
define("dijit/form/nls/ko/Textarea",{iframeEditTitle:"\ud3b8\uc9d1 \uc601\uc5ed",iframeFocusTitle:"\ud3b8\uc9d1 \uc601\uc5ed \ud504\ub808\uc784"});
//@ sourceMappingURL=Textarea.js.map