// Dojo Mobile tutorial | Flickrview | Part III
define([
	"dojo/_base/declare",
	"dojox/mobile/ScrollableView"
], function(declare, ScrollableView){
	return declare([ScrollableView], {
	});
});