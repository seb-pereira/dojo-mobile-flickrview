// Dojo Mobile tutorial | Flickrview | Part II
define([
	"dojo/_base/declare",
	"dojox/mobile/ScrollableView"
], function(declare, ScrollableView){
	return declare([ScrollableView], {
	});
});